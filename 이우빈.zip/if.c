#include<stdio.h>
 
main()
{

	int num = 10;
	printf("Enter a number between 0~100: ");
	scanf("%d", &num);
	
	if(num==0){
		printf("Hello");
	}
	else{
		printf("I's designated value isn't 0");
	}

}

