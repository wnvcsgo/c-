#include <stdio.h>

int main()
{

   int count;
   int answer=1; 

   printf( "\nThe odd numbers 1-10 are\n");

   for( count=1; count<=10; count+=2 ){
	 answer =count*answer; 
	  printf("%d\n", count);
   
	  }

   printf( "\nAnswer is \n%d", answer);



return 0;

}

