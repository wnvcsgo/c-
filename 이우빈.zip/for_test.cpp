#include <iostream>
using namespace std;

int main()
{
	int sum = 0;
	for (int i =1; i< 101;i = i+1){
	sum = sum + i;
	printf("Sum of 1~100 = %d\n", sum);	}
return 0;
}

