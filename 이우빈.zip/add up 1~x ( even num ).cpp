#include <iostream>
	
 	
int main ()
{
	int sum = 0;
		
	for(int i =1; i<11; i = i+1)
   {
       sum = sum+2;
	   
	   printf("The sum "
	   "is : %d, %d, %d, %d \n",i, 3, 6, sum);
	}

   return 0;
}   

