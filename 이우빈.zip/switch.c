
#include<stdio.h>
 
main()
{
	
	int i = 5699965;
	switch(i){
	
	case 1:
			printf("I is 1.");
			printf("this is case 1");
			break;
	case 2:
			printf("I os 2");
			printf("this is case 2");
			break;
	default:
			printf("I is %d", i);
			printf("This is the default configuration");
			break;
			sleep(599);
	}
}

