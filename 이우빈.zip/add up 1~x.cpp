#include <iostream>
	
 	
int main ()
{

int sum = 0;	
	for(int i =1; i<1001; i = i+1)
   {
       sum = sum+i;
	   printf("The sum of 1 to 1000 is %d \n",sum);
	  
   }
	
   return 0;
}   

