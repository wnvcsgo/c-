#include <stdio.h>

int main()
{
	int a,byul,n;
	int c;
	scanf("%d",&n);
	
	for(a=0;a<n; a++)
	{
		for(byul=0;byul<(n-1)-a;byul++)
		{
			printf(" ");
			
		}	
		for(c=0;c<a;c++)
		{
			printf("*");
		}
		for(c=0;c<a+1;c++)
		{
			printf("*");
		}	  	  	  
		
		
	
	printf("\n");
	
	}
	
		for(a=0;a<n-1; a++)
	{	
		for(c=0;c<a+1;c++)
		{
			printf(" ");
		}	  	  	  
		
		for(byul=0;byul<(n-1)-a;byul++)
		{
			printf("*");
			
		}	
			for(byul=0;byul<(n-2)-a;byul++)
		{
			printf("*");
			
		}	
		
		
	
	printf("\n");
	
	}
}	 
	/*for(byul=0;byul<(n-1)-a;byul++)
		
		{
			printf(" ");
		}	  	  for(c=0;c<a;c++)
		{
			printf("*");
		}
		for(c=0;c<a+1;c++)
		{
			printf("*");
		}*/    


